AYUSH YADAV — PORTFOLIO WEBSITE

Files:
- index.html: complete responsive website (HTML, CSS and JavaScript in one file)
- assets/: your portrait and six project photographs, optimised as WebP

Preview locally:
1. Keep index.html and the assets folder together.
2. Open index.html in Chrome, Edge or Firefox.

Publish to your existing GitHub Pages repository:
1. Download and extract this ZIP.
2. Open https://github.com/Ayushnexus/Ayushnexus.github.io
3. Back up your current index.html and assets first.
4. Upload the new index.html and the complete assets folder to the repository root.
5. Commit the changes. GitHub Pages will publish the updated site.

Notes:
- The Motion ON/OFF control is functional and remembers the preference in the browser.
- The menu adapts for mobile screens.
- Scroll reveal animations respect reduced-motion preferences.
- Verify all dates, qualifications, metrics, email, phone and LinkedIn URL before publishing.
- The LinkedIn button currently uses the general LinkedIn homepage because the precise profile URL was not included in the live page text. Replace it with your exact profile URL before publishing.
